import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import sun.misc.BASE64Encoder;
import java.util.Scanner;

public class Learn{
  private static final String LINE_FEED = "\r\n";
  private static final String BASE_URL = "http://localhost:8080/fedora/";

  private static Object content;
  private static String boundary;
  private static HttpURLConnection httpConn;
  private static String charset;
  private static OutputStream outputStream;
  private static PrintWriter writer;
  private static String CRLF = "\r\n"; // Line separator required by multipart/form-data.

  public static String createDataStream(String _pid, String _dsid, String _mimeType, String _logmsg, String label, File snd_file, String mime){
      try{
          return upload(
                  BASE_URL+"objects/"
                  +_pid
                  +"/datastreams/"
                  + _dsid+"?"
                  + "mimeType=" + _mimeType
                  + "&dsLabel=" +label
                  + "&logMessage=" + URLEncoder.encode(_logmsg, "UTF-8"),
                  snd_file,
                  mime
                  );
      }catch(Exception e){
          return e.getMessage();
      }
  }

  public static String createObject(String _label,String _namespace, String _owner){
      try{
          return sendPostRequest(BASE_URL
                  +"objects/new?flash=false"
                  + "&label=" + _label
                  + "&namespace=" + _namespace
                  + "&ownerId=" + URLEncoder.encode(_owner, "UTF-8"));
      }catch(Exception e){
          return e.getMessage();
      }
  }

  public static String sendPostRequest(String requestUrl) {
          StringBuffer jsonString = null;
          try {
              URL url = new URL(requestUrl);
              HttpURLConnection connection = (HttpURLConnection) url.openConnection();
              connection.setDoInput(true);
              connection.setDoOutput(true);
              connection.setRequestMethod("POST");
              connection.setRequestProperty("User-Agent", "CodeJava Agent");
              connection.setRequestProperty("Authorization", "Basic "+(new BASE64Encoder()).encode(("fedoraAdmin"+":"+"fedoraAdmin").getBytes()));
              connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
              connection.setRequestProperty("Accept-Language", "Accept-Language");
              connection.setRequestProperty("Connection", "keep-alive");
              connection.setRequestProperty("Accept-Encoding", "gzip, deflate");
              connection.setRequestProperty("Content-Type", "text/xml");

              BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
              jsonString = new StringBuffer();
              String line;
              while ((line = br.readLine()) != null) {
                  jsonString.append(line);
              }
              br.close();
              connection.disconnect();
          } catch (Exception e) {
              throw new RuntimeException(e.getMessage());
          }
          return jsonString.toString();
      }

      public static String upload(String url, File snd_file, String mime) throws IOException{
              String charset = "UTF8";
              String param = "value";
              String boundary = Long.toHexString(System.currentTimeMillis()); // Just generate some unique random value.
              URLConnection connection = new URL(url).openConnection();
              connection.setDoOutput(true);
              connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
              connection.setRequestProperty("Authorization", "Basic "+(new BASE64Encoder()).encode(("fedoraAdmin"+":"+"fedoraAdmin").getBytes()));
              connection.setRequestProperty("Accept", mime+",*");
              connection.setRequestProperty("Connection", "keep-alive");
              connection.setRequestProperty("Accept-Encoding", "gzip, deflate, UTF8, UTF-8");
              connection.setRequestProperty("enctype", "multipart/form-data");
              try (
                  // InputStream inputstream =
                  OutputStream output = connection.getOutputStream();
                  PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, charset), true);
              ){
              // Send file
              writer.append("--" + boundary).append(CRLF);
              writer.append("Content-Disposition: form-data; name=\"param\"").append(CRLF);
              writer.append("Content-Type: "+mime+"; charset=" + charset).append(CRLF);
              writer.append(CRLF).append(param).append(CRLF).flush();
              writer.append("--" + boundary).append(CRLF);
              writer.append("Content-Disposition: form-data; name=\"file\"; filename=\"" + snd_file.getName() + "\"").append(CRLF);
              writer.append("Content-Type: "+mime+"; charset=" + charset).append(CRLF); // Text file itself must be saved in this charset!
              writer.append(CRLF).flush();

              Files.copy(snd_file.toPath(), output);
              output.flush(); // Important before continuing with writer!

              writer.append(CRLF).flush(); // CRLF is important! It indicates end of boundary.
              writer.append("--" + boundary + "--").append(CRLF).flush();
          }

          // Request is lazily fired whenever you need to obtain information about response.
          int responseCode = ((HttpURLConnection) connection).getResponseCode();
          System.out.println(responseCode); // Should be 200
          return ""+responseCode;
    }

    public static void main(String[] args) throws Exception {
        //Scanner input = new Scanner(System.in);
        //System.out.print("Please enter file name: ");
        //File snd_file = new File(input.nextLine());
        File snd_file = new File("binary.jpeg");
        System.out.println("File exists : " +snd_file.exists());
        System.out.println("File can be Read : " +snd_file.canRead());
        System.out.println("File can be written : " +snd_file.canRead());
        String file_name = snd_file.getName();
        String mime = URLConnection.guessContentTypeFromName(file_name);
        InputStreamReader r = new InputStreamReader(new FileInputStream(snd_file));

        System.out.println("mimeType : "+mime);
        String pid = createObject("Love12","cs101", "Lavius Nkateko Motileng");
        System.out.println("PID : "+pid);
        createDataStream(pid, "cake", mime, "uploading first version of the file",file_name, snd_file, mime);
    }
}
