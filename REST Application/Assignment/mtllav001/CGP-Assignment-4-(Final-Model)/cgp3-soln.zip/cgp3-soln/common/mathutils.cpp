/**
 * @file
 *
 * Miscellaneous maths utilities.
 */
#include "mathutils.h"

template bool isPower2Ratio<float>(float, float);
