/****************************************************************************
** Meta object code from reading C++ file 'window.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "window.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'window.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Window_t {
    QByteArrayData data[28];
    char stringdata[310];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_Window_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_Window_t qt_meta_stringdata_Window = {
    {
QT_MOC_LITERAL(0, 0, 6),
QT_MOC_LITERAL(1, 7, 12),
QT_MOC_LITERAL(2, 20, 0),
QT_MOC_LITERAL(3, 21, 12),
QT_MOC_LITERAL(4, 34, 12),
QT_MOC_LITERAL(5, 47, 13),
QT_MOC_LITERAL(6, 61, 11),
QT_MOC_LITERAL(7, 73, 10),
QT_MOC_LITERAL(8, 84, 10),
QT_MOC_LITERAL(9, 95, 9),
QT_MOC_LITERAL(10, 105, 7),
QT_MOC_LITERAL(11, 113, 4),
QT_MOC_LITERAL(12, 118, 10),
QT_MOC_LITERAL(13, 129, 8),
QT_MOC_LITERAL(14, 138, 8),
QT_MOC_LITERAL(15, 147, 6),
QT_MOC_LITERAL(16, 154, 16),
QT_MOC_LITERAL(17, 171, 17),
QT_MOC_LITERAL(18, 189, 10),
QT_MOC_LITERAL(19, 200, 9),
QT_MOC_LITERAL(20, 210, 12),
QT_MOC_LITERAL(21, 223, 4),
QT_MOC_LITERAL(22, 228, 15),
QT_MOC_LITERAL(23, 244, 13),
QT_MOC_LITERAL(24, 258, 14),
QT_MOC_LITERAL(25, 273, 2),
QT_MOC_LITERAL(26, 276, 14),
QT_MOC_LITERAL(27, 291, 17)
    },
    "Window\0optionsReset\0\0repaintAllGL\0"
    "resetOptions\0resetTemporal\0terrainSwap\0"
    "pointsMode\0curvesMode\0typesMode\0newFile\0"
    "open\0exportFile\0exportAs\0saveFile\0"
    "saveAs\0showSynthOptions\0showRenderOptions\0"
    "showManips\0editTypes\0showContours\0"
    "show\0showManipDecals\0showGridLines\0"
    "toggleTerScale\0on\0lineEditChange\0"
    "scaleFactorChange\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Window[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      24,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  134,    2, 0x05,

 // slots: name, argc, parameters, tag, flags
       3,    0,  135,    2, 0x0a,
       4,    0,  136,    2, 0x0a,
       5,    0,  137,    2, 0x0a,
       6,    0,  138,    2, 0x0a,
       7,    0,  139,    2, 0x0a,
       8,    0,  140,    2, 0x0a,
       9,    0,  141,    2, 0x0a,
      10,    0,  142,    2, 0x0a,
      11,    0,  143,    2, 0x0a,
      12,    0,  144,    2, 0x0a,
      13,    0,  145,    2, 0x0a,
      14,    0,  146,    2, 0x0a,
      15,    0,  147,    2, 0x0a,
      16,    0,  148,    2, 0x0a,
      17,    0,  149,    2, 0x0a,
      18,    0,  150,    2, 0x0a,
      19,    0,  151,    2, 0x0a,
      20,    1,  152,    2, 0x0a,
      22,    1,  155,    2, 0x0a,
      23,    1,  158,    2, 0x0a,
      24,    1,  161,    2, 0x0a,
      26,    0,  164,    2, 0x0a,
      27,    0,  165,    2, 0x0a,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void, QMetaType::Int,   25,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Window::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Window *_t = static_cast<Window *>(_o);
        switch (_id) {
        case 0: _t->optionsReset(); break;
        case 1: _t->repaintAllGL(); break;
        case 2: _t->resetOptions(); break;
        case 3: _t->resetTemporal(); break;
        case 4: _t->terrainSwap(); break;
        case 5: _t->pointsMode(); break;
        case 6: _t->curvesMode(); break;
        case 7: _t->typesMode(); break;
        case 8: _t->newFile(); break;
        case 9: _t->open(); break;
        case 10: _t->exportFile(); break;
        case 11: _t->exportAs(); break;
        case 12: _t->saveFile(); break;
        case 13: _t->saveAs(); break;
        case 14: _t->showSynthOptions(); break;
        case 15: _t->showRenderOptions(); break;
        case 16: _t->showManips(); break;
        case 17: _t->editTypes(); break;
        case 18: _t->showContours((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->showManipDecals((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->showGridLines((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->toggleTerScale((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->lineEditChange(); break;
        case 23: _t->scaleFactorChange(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Window::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Window::optionsReset)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject Window::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Window.data,
      qt_meta_data_Window,  qt_static_metacall, 0, 0}
};


const QMetaObject *Window::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Window::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Window.stringdata))
        return static_cast<void*>(const_cast< Window*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Window::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 24)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 24;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 24)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 24;
    }
    return _id;
}

// SIGNAL 0
void Window::optionsReset()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
